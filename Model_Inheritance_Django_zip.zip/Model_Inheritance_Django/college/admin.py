from django.contrib import admin
from .models import Student


# from .models import Student
# from .models import Examcenter
# from .models import Myexamcenter
# from .models import Student, Teacher, Contractor

# admin.site.register(Student)
# admin.site.register(Teacher)
# admin.site.register(Contractor)

# admin.site.register(Student)
# admin.site.register(Examcenter)

# admin.site.register(Examcenter)
# admin.site.register(Myexamcenter)


# # ========================== Model Manager ==================
# admin.site.register(Student)