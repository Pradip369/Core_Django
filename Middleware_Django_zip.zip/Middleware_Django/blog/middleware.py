# def my_middleware(get_response):
#     print("One time intialization")
#     def my_function(request):
#         print("This is before view")
#         response = get_response(request)
#         print("This is after view")
#         return response
#     return my_function 


from django.http.response import HttpResponse

# class my_brother_middleware:
#     def __init__(self,get_response):
#         self.get_response = get_response
#         print("One time Intialization brother")
        
#     def __call__(self,request):
#         print("This is before brother views")
#         response = self.get_response(request)
#         print("This is after brother views")    
#         return response 
    
    
# class my_father_middleware:
#     def __init__(self,get_response):
#         self.get_response = get_response
#         print("One time Intialization father")
        
#     def __call__(self,request):
#         print("This is before father views")
#         # response = self.get_response(request)
#         response = HttpResponse("hII You Are graet programmer")
#         print("This is after father views")    
#         return response     
    
    
# class my_mother_middleware:
#     def __init__(self,get_response):
#         self.get_response = get_response
#         print("One time Intialization mother ")
        
#     def __call__(self,request):
#         print("This is before mother views")
#         response = self.get_response(request)
#         print("This is after mother views")    
#         return response    



# class Myprocess:
#     def __init__(self,get_response):
#         self.get_response = get_response
        
#     def __call__(self,request):
#         response = self.get_response(request)  
#         return response
    
#     def process_view(request,*args,**kwargs):
#         print("This is duplicate view")
#         return HttpResponse("<h1>This Page Is Under Construction!!!</h1>")
        # return None
    
# class Myexception:
#     def __init__(self,get_response):
#         self.get_response = get_response
        
#     def __call__(self,request):
#         response = self.get_response(request)  
#         return response   
    
#     def process_exception(self,request,exception):
#         msg = exception
#         return HttpResponse(msg) 
    
    
# class Mytemplate:
#     def __init__(self,get_response):
#         self.get_response = get_response
        
#     def __call__(self,request):
#         response = self.get_response(request)  
#         return response   
    
#     def process_template_response(self,request,response):
#         print("This is duplicate template")
#         response.context_data["name"] = "Kachhadiya"
#         return response
