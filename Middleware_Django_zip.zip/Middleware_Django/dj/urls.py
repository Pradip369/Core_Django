# from django.contrib import admin
# from django.urls import path
# from blog import views

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('home/',views.home),
#     path('about/',views.about),
    # path('exc/',views.exc),
    # path('user/',views.user_info),
# ]