from django.shortcuts import render
from .models import School
from django.db.models.aggregates import Avg, Sum, Min, Max, Count
# from django.db.models.query_utils import Q

# ================================ Return Queryset ==============================

# def home(req):
    # td = School.objects.all()
    
    # td = School.objects.filter(marks=98)
    
    # td = School.objects.exclude(marks=98)
    
    # td = School.objects.order_by('marks')
    # td = School.objects.order_by('-marks')
    # td = School.objects.order_by('?') 
    
    # td = School.objects.order_by('id').reverse()[:5]
    # td = School.objects.order_by('id').reverse()
    
    # td = School.objects.values("name","roll")   #Specific raw selection
    # td = School.objects.values_list("name","roll",named=True)
    
    
    # td1 = School.objects.values_list("name","roll",named=True)
    # td2 = College.objects.values_list("name","roll",named=True)
    # data = td2.intersection(td1)
    
    # td1 = School.objects.values_list("name","roll",named=True)
    # td2 = College.objects.values_list("name","roll",named=True)
    # data = td2.difference(td1)
    
    # td = School.objects.filter(Q(id=1) | Q(id=2))
    # td = School.objects.filter(Q(id=1) & Q(id=2))


    # return render(req,"home.html",{"td":td})
    
    
# =============================== Not Return Queryset ========================
    
# def home(req):
    
    # td = School.objects.get(pk=1)
    
    # td = School.objects.latest("cr_date")
   
    # td = School.objects.earliest("cr_date")
    
    # td_d = School.objects.all()
    # td = School.objects.get(pk=1)
    # print(td_d.filter(pk=td.pk).exists())
    
    # sd = School.objects.create(name="kp",surname="kachh..",roll=20,marks=97)
      
    # td = School.objects.get_or_create(name="kp",surname="kachh..",roll=20,marks=97)
    
    # td = School.objects.filter(pk=1).update(name="pradip1",roll=2004)
    
    # td = School.objects.get(pk=1).delete()
    
    # td = School.objects.all()
    # print(td.count())
    
    # return render(req,"home.html",{"td":td})
    
    
# =============================  Field Lookups  ================================
    
def home(req):
    # td = School.objects.all()
    
    # td = School.objects.filter(name__exact="pradip")
    # td = School.objects.filter(name__iexact="Pradip")
    
    # td = School.objects.filter(name__contains="a")
    # td = School.objects.filter(name__icontains="A")

    td = School.objects.filter(roll__in=[2001,2004])
    
    # td = School.objects.filter(marks__gt=60)
    # td = School.objects.filter(marks__gte=10)
    # td = School.objects.filter(marks__lt=60)
    # td = School.objects.filter(marks__lte=60)
    
    # td = School.objects.filter(name__startswith="p")
    # td = School.objects.filter(name__istartswith="P")
    
    # td = School.objects.filter(name__endswith="p")
    # td = School.objects.filter(name__iendswith="P")
    
    # td = School.objects.filter(id__range=('1','5'))
    
    
    return render(req,"home.html",{"td":td})


# ================================ Aggregate ==============================

# def home(req):
#     td = School.objects.all()
#     avg = td.aggregate(Avg('marks'))
#     sum = td.aggregate(Sum('marks'))
#     min = td.aggregate(Min('marks'))
#     max = td.aggregate(Max('marks'))
#     count = td.aggregate(Count('marks'))
    
    
#     td = School.objects.all()[1:5]

#     return render(req,"home.html",{"td":td,"avg":avg,"sum":sum,"min":min,"max":max,"count":count})