from django.db import models

class School(models.Model):
    name = models.CharField(max_length=30)
    surname = models.CharField(max_length=30)
    roll = models.IntegerField(unique=True)
    marks = models.IntegerField()
    cr_date = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name
