from django.contrib.auth.models import User
from django.contrib.auth.signals import user_logged_in, user_logged_out,\
    user_login_failed
from django.dispatch.dispatcher import receiver
from django.db.models.signals import pre_save, post_save, pre_delete,\
    post_delete, pre_init, post_init
from django.core.signals import request_started, request_finished,\
    got_request_exception






@receiver(user_logged_in,sender=User)
def login_user(sender,request,user,**kwargs):
    print("====================  LOGIN USER  ==========================")
    print(sender)
    print(request)
    print(user.password)
    print(kwargs)
    print(f"kwargs:  {kwargs}")

# user_logged_in.connect(login_user,sender=User)   

@receiver(user_logged_out,sender=User)
def logout_user(sender,request,user,**kwargs):
    print("====================  LOGOUT USER  ==========================")
    print(sender)
    print(request)
    print(user.password)
    print(kwargs)
    print(f"kwargs:  {kwargs}")

# user_logged_out.connect(logout_user,sender=User) 

@receiver(user_login_failed)
def login_fail(sender,request,credentials,**kwargs):
    print("====================  LOGIN FAILED  ==========================")
    print(sender)
    print(request)
    print(credentials)
    print(kwargs)
    print(f"kwargs:  {kwargs}")

# user_login_failed.connect(login_fail,sender=User)









@receiver(pre_save,sender=User)
def at_beginning_save(sender,instance,**kwargs):
    print("==================== At Pre Save  ==========================")
    print(sender)
    print(instance)
    print(f"kwargs:  {kwargs}")
# pre_save.connect(at_beginning_save,sender=User)

@receiver(post_save,sender=User)
def at_ending_save(sender,instance,created,**kwargs):
    print("==================== Post Save  ==========================")
    if created:
        print("=======================New Created=====================")
        print(sender)
        print(instance)
        print(created)
        print(f"kwargs:  {kwargs}")
    else:
        print("=======================Updated=====================")

        print(sender)
        print(instance)
        print(created)
        print(f"kwargs:  {kwargs}")   
# post_save.connect(at_ending_save,sender=User)








@receiver(pre_delete,sender=User)
def at_beginning_delete(sender,instance,**kwargs):
    print("==================== At Pre Delete  ==========================")
    print(sender)
    print(instance)
    print(f"kwargs:  {kwargs}")
# pre_delete.connect(at_beginning_delete,sender=User)


@receiver(post_delete,sender=User)
def at_ending_delete(sender,instance,**kwargs):
    print("==================== At Post Delete  ==========================")
    print(sender)
    print(instance)
    print(f"kwargs:  {kwargs}")
# post_delete.connect(at_ending_delete,sender=User)






@receiver(pre_init,sender=User)
def at_beginning_init(sender,*args,**kwargs):
    print("==================== At Pre Inits  ==========================")
    print(sender)
    print(args)
    print(f"kwargs:  {kwargs}")
# pre_init.connect(at_beginning_init,sender=User)

@receiver(post_init,sender=User)
def at_ending_init(sender,*args,**kwargs):
    print("==================== At Post Inits  ==========================")
    print(sender)
    print(args)
    print(f"kwargs:  {kwargs}")
# post_init.connect(at_ending_init,sender=User)






@receiver(request_started)
def at_beginning_request(sender,environ,**kwargs):
    print("==================== At Pre Request ==========================")
    print(sender)
    print(environ)
    print(f"kwargs:  {kwargs}")
# request_started.connect(at_beginning_request,sender=User)

@receiver(request_finished)
def at_ending_request(sender,**kwargs):
    print("==================== At Request Finishing ==========================")
    print(sender)
    print(f"kwargs:  {kwargs}")
# request_finished.connect(at_ending_request,sender=User)





@receiver(got_request_exception)
def at_request_exception(sender,request,**kwargs):
    print("==================== At Request Exception ==========================")
    print(sender)
    print(request)
    print(f"kwargs:  {kwargs}")
# got_request_exception.connect(at_request_exception,sender=User)




