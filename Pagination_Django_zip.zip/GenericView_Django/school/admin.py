from django.contrib import admin
from .models import School

admin.site.register(School)