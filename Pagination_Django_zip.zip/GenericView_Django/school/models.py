from django.db import models
from django.urls.base import reverse

class School(models.Model):
    name = models.CharField(max_length=20)
    roll = models.IntegerField()
    course = models.CharField(max_length=30)
    
    def __str__(self):
        return '%s(%s)' %(self.name,self.id)
    
    # def get_absolute_url(self):
    #     return reverse("formcreate")