from django.shortcuts import render
from .models import Post
from django.core.paginator import Paginator
from django.views.generic.list import ListView
from django.http.response import Http404
from django.views.generic.detail import DetailView

def all_post(request):
    ps = Post.objects.all().order_by('id')
    # print("all page::",ps)
    
    paginator = Paginator(ps,3,orphans=2)
    
    page_number = request.GET.get('page')
    # print("Page number :: ",page_number)
    
    page_obj = paginator.get_page(page_number)
    # print("page obj::",page_obj)
    
    return render(request,'home.html',{'page_obj':page_obj})


class Allpost(ListView):
    model = Post
    template_name = 'home.html'
    ordering = ['id']
    paginate_by = 3
    paginate_orphans = 1
    
    def get_context_data(self,*args,**kwargs):
        try:
            return super(Allpost,self).get_context_data(*args,**kwargs)
        except Http404:
            self.kwargs['page'] = 1
            return super(Allpost,self).get_context_data(*args,**kwargs)
        
    def paginate_queryset(self,queyrset,page_size):
        try:
            return super(Allpost,self).paginate_queryset(queyrset,page_size)
        except Http404:
            self.kwargs['page'] = 1
            return super(Allpost,self).paginate_queryset(queyrset,page_size)


class Allpostdetail(DetailView):
    model = Post
    template_name = 'detail.html'