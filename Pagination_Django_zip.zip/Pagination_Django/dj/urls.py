from django.contrib import admin
from django.urls import path
from blog import views

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('', views.all_post),
    path('', views.Allpost.as_view()),
    path('detail/<int:pk>', views.Allpostdetail.as_view()),


]
