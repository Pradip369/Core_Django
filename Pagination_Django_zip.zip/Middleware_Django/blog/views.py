# from django.shortcuts import render
# from django.http.response import HttpResponse
# from django.template.response import TemplateResponse

# def home(request):
#     print("I am real view")
#     return HttpResponse("This is home view")

# def about(request):
#     return HttpResponse("This is about page")
# def exc(request):
#     print("My exception")
#     a = 10/0
#     return HttpResponse("None")

# def user_info(request):
#     print("I am user info view")
#     context = {"name":"Pradip"}
#     return TemplateResponse(request,"user.html",context)