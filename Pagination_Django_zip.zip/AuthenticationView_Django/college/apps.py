from django.apps import AppConfig


class CollgeConfig(AppConfig):
    name = 'collge'
