from django.shortcuts import render
# from django.views.generic.base import View, TemplateView
# from django.http.response import HttpResponse
# from .forms import Myform

# =========================== Class Base Views =======================


# =========================== [1] get request===============================

# class Myview(View):
#     def get(self,request):
#         cn  = {"name":"pradip"}
#         return render(request,"home.html",cn)
    
    

# ===================== [2] Post request =====================

# class MyForm(View):
#     def get(self,request):
#         fm = Myform()
#         return render(request,"home.html",{"fm":fm})    
    
#     def post(self,request):
#         fm = Myform(request.POST)
#         if fm.is_valid():
#             print("Your form is successfully submitted")
#         return HttpResponse("Thank you for submitted!!!")




# # ========================== Template View =======================

# class Mytemplateview(TemplateView):
#     template_name = "home.html"
    
    
#     def get_context_data(self,**kwargs):
#         context = super().get_context_data(**kwargs)
#         context['name'] = "Pradip"
#         context['surname'] = "Kachhadiya"
#         return context