from django.shortcuts import render
from .models import Student
# from .models import Student
# from .models import Teacher, Contractor

# # Create your views here.
# def home(req):
#     td1 = Student.objects.all()
#     td2 = Teacher.objects.all()
#     td3 = Contractor.objects.all()
#     return render(req,"home.html",{"td1":td1,"td2":td2,"td3":td3})


def home(req):
    td1 = Student.student.all()

    return render(req,"home.html",{"td1":td1})