from django.db import models


# ===================================== Abstract Method ================================

# class Commoninfo(models.Model):
#     name = models.CharField(max_length=20)
#     age = models.IntegerField()
#     date = models.DateField()
#     class Meta:
#         abstract = True
        
# class Student(Commoninfo):
#     fees = models.IntegerField()
#     date = None
#     def __str__(self):
#         return self.name
           
           
# class Teacher(Commoninfo):
#     salary = models.IntegerField()
#     def __str__(self):
#         return self.name
    
# class Contractor(Commoninfo):
#     payment = models.IntegerField()
#     date = models.DateTimeField() 
#     def __str__(self):
#         return self.name           
    

# ================= one to one model relation ===============

# class Examcenter(models.Model):
#     cname = models.CharField(max_length=20)
#     city = models.CharField(max_length=25)
#     def __str__(self):
#         return self.city
    
    
# class Student(Examcenter):
#     name = models.CharField(max_length=20)
#     roll = models.IntegerField()
#     def __str__(self):
        
#         return self.name
    
    
# # ===================== Proxy table ===========

# class Examcenter(models.Model):
#     cname = models.CharField(max_length=20)
#     city = models.CharField(max_length=25)
    
# class Myexamcenter(Examcenter):
#     class Meta:
#         proxy = True
     
     
# # ================================  Change Manager =====================
# class Student(models.Model):
#     name = models.CharField(max_length=20)
#     age = models.IntegerField()
#     student = models.Manager()