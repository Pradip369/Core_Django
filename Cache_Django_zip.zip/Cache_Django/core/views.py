from django.shortcuts import render
from django.views.decorators.cache import cache_page
from django.core.cache import cache



def set_cache_v(req):
    ch = cache.get('planet',"no data")
    if ch == "no data":
        cache.set('planet','mars',20)
        ch = cache.get('planet')
    return render(req,"set.html",{"pn":ch})


def set_cache_v(req):
    ch = cache.get_or_set('planet',"moon",10,version=2)
    return render(req,"set.html",{"pn":ch})


def set_cache_v(req):
    data = {"name":'pradip','roll':2001}
    cache.set_many(data,20)
    sv = cache.get_many(data)
    return render(req,"set.html",{"pn":sv})

def set_cache_v(req):
    cache.delete('planet')
    return render(req,"set.html")

def set_cache_v(req):
      cache.set("roll",5,600)
    dv = cache.decr('roll',delta=1) 
    print(dv)   
    
    dv = cache.incr('roll',delta=2) 
    print(dv)
    return render(req,"set.html")

def set_cache_v(req):
    cache.set("roll",5,600)
    cache.clear()
    return render(req,"set.html")



