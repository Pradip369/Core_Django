from django.urls import path
from . import views

urlpatterns = [
    path('set/', views.set_cache_v),
    # path('get/', cache_page(20)(views.get_cache_v)),
    # path('get2/', views.get_cache_v),
    # path('del/', views.del_session),
    # path('home/', views.home),
]
