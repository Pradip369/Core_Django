from django.urls import path
from . import views
from django.views.generic.base import RedirectView

urlpatterns = [
    
    # path('',views.Myview.as_view()),
    # path('form/',views.MyForm.as_view()),
    
    path('temp/',views.Mytemplateview.as_view()),
    path('',RedirectView.as_view(url = "temp/"))
    
]
