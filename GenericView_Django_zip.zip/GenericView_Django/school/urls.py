from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.Studentlistview.as_view()),
    
    path('detail/<int:pk>', views.Studentdetail.as_view()),
    
    path('form/', views.My_form.as_view()),
    path('thanks/', views.Thanks.as_view()),
    
    path('create/', views.Formcreate.as_view(),name = "formcreate"),
    
    path('update/<int:pk>', views.Formupdate.as_view(),name = "formupdate"),

    path('delete/<int:pk>', views.Formdelete.as_view(),name = "formdelete"),


]
