from django.views.generic.list import ListView
from .models import School
from django.views.generic.detail import DetailView
from django.views.generic.edit import FormView, CreateView, UpdateView,\
    DeleteView
from .forms import Myform
from django.views.generic.base import TemplateView
from django.http.response import HttpResponse
from django import forms


# =========================================== List view ===========================================

class Studentlistview(ListView):
    model = School



#   ========================= Costmization ====================
  
# class Studentlistview(ListView):
#     model = School  

#     template_name = 'school/school.html'  
#     template_name_suffix = '_list'
#     ordering = ["name"]
#     context_object_name = "st"
    
#     def get_queryset(self):
#       return School.objects.filter(course="mech")
    
#     def get_template_names(self):
#       if self.request.user.is_superuser:
#         template_name = "school/superuser.html"
#       else:
#         template_name = self.template_name
#       return [template_name]  


# ================================== Detail View ============================

class Studentdetail(DetailView):
    model = School
  
  
# ============= Customijetion ==============

# class Studentdetail(DetailView):
#     model = School
    
#     template_name = 'school/school.html'
#     context_object_name = "st"
#     pk_url_kwarg = "id"


# =================================== Generic Editing View ==========================================

# ==================== Form View ====================

class My_form(FormView):
  template_name = 'school/contact.html'
  form_class = Myform
  success_url = '/thanks/'
  
  # =========================== Aditional feature =====================
  
  def form_valid(self,form):
    print(form.cleaned_data["name"])
    print(form.cleaned_data["email"])
    print(form.cleaned_data["msg"])
    return HttpResponse("Thank You For register bro!!!!!!!!!")
  
class Thanks(TemplateView):
    template_name = 'school/thanks.html'

# =========================== Create View ===================

class Formcreate(CreateView):
  model = School
  fields = ["name","roll","course"]
  success_url  = '/thanks/'
  
  def get_form(self):
    form = super().get_form()
    form.fields["name"].widget = forms.TextInput(attrs={'class':'myclass'})
    form.fields["roll"].widget = forms.NumberInput(attrs={'class':'myint'})
    form.fields["course"].widget = forms.TextInput(attrs={'class':'mycs'})
    return form
    
    
# =========================== Update View =======================

class Formupdate(UpdateView):
  model = School
  fields = '__all__'
  success_url = '/thanks/'
  
  
  # =================== For apply css =================
  
  def get_form(self):
    form = super().get_form()
    form.fields["name"].widget = forms.TextInput(attrs={'class':'myclass'})
    form.fields["roll"].widget = forms.NumberInput(attrs={'class':'myint'})
    form.fields["course"].widget = forms.TextInput(attrs={'class':'mycs'})
    return form

# ==================== Delete View ===================

class Formdelete(DeleteView):
  model = School
  success_url = '/list/'