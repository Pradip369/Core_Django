# from django.db import models
# from django.contrib.auth.models import User


# ================================== one to one Relationship =================================

# class Page(models.Model):
#     user = models.OneToOneField(User,on_delete = models.CASCADE,primary_key=True)
#     page_name = models.CharField(max_length=20)
#     page_cat = models.CharField(max_length=20)
#     page_publish_date = models.DateField()
    
#     def __str__(self):
#         return str(self.user)
    
    
# class Page(models.Model):
#     user = models.OneToOneField(User,on_delete = models.PROTECT,primary_key=True)
#     page_name = models.CharField(max_length=20)
#     page_cat = models.CharField(max_length=20)
#     page_publish_date = models.DateField()
    
#     def __str__(self):
#         return str(self.user)
    
    
# class Page(models.Model):
#     user = models.OneToOneField(User,on_delete = models.CASCADE,primary_key=True,limit_choices_to={"is_staff":True})
#     page_name = models.CharField(max_length=20)
#     page_cat = models.CharField(max_length=20)
#     page_publish_date = models.DateField()
    
#     def __str__(self):
#         return str(self.user) 


# ==================================== many to one Relationship ===============================


# class Page(models.Model):
#     user = models.ForeignKey(to=User,on_delete = models.CASCADE)
    
#     # user = models.ForeignKey(to=User,on_delete = models.PROTECT)
#     # user = models.ForeignKey(to=User,on_delete = models.SET_NULL,null=True)
    
#     page_name = models.CharField(max_length=20)
#     page_cat = models.CharField(max_length=20)
#     page_publish_date = models.DateField()
    
#     def __str__(self):
#         return str(self.user)


# =========================== Many to Many Relationship =======================

# class Song(models.Model):
#     user = models.ManyToManyField(to=User) 
#     song_name = models.CharField(max_length=20)
#     song_cat = models.CharField(max_length=20)
#     song_publish_date = models.DateField()
    
    
#     def singer_name(self):
#         return ",".join([str(i) for i in self.user.all()])