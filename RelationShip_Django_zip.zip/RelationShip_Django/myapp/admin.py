from django.contrib import admin
# from .models import Page
# from .models import Song

# admin.site.register(Page)

# class SongAdmin(admin.ModelAdmin):
#     list_display = ["song_name","singer_name"]
    
# admin.site.register(Song,SongAdmin)    
