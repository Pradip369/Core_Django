# from django.dispatch.dispatcher import receiver
# from django.db.models.signals import post_delete
# from .models import Page




# @receiver(post_delete,sender=Page)
# def delete_related_user(sender,instance,**kwargs):
#     print("Delete User")
#     print(instance)
#     instance.user.delete()
