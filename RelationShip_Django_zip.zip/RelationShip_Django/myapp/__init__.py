# from django.contrib.admin import default_app_config
# default_app_config = 'myapp.apps.MyappConfig'