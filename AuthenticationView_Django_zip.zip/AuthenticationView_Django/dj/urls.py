from django.contrib import admin
from django.urls import path
from django.urls.conf import include
from college import views
from django.contrib.auth import views as auth_view
from django.views.generic.base import TemplateView
from college.forms import Loginform

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('accounts/', include('django.contrib.auth.urls')),
    # # path('accounts/profile/', views.profile),
    # path('accounts/profile/', views.Myprofile.as_view()),
   path('',views.home),
   path('profile/', views.Myprofile.as_view()),
   path('dashboard/',TemplateView.as_view(template_name='registration/dashboard.html')),
   
   
   path('login/',auth_view.LoginView.as_view(template_name='registration/login.html',authentication_form=Loginform)),
   
   path('logout/',auth_view.LogoutView.as_view(template_name='registration/logout.html')),
   path('changepass/',views.Mychangepass.as_view()),
   path('changepassdone/',auth_view.PasswordResetDoneView.as_view(template_name='registration/changepassdone.html')),

]
