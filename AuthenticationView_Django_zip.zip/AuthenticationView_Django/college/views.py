from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.views.generic.base import TemplateView
from django.utils.decorators import method_decorator
from django.contrib.auth.views import PasswordChangeView

@method_decorator(login_required,name='dispatch')
class Myprofile(TemplateView):
    template_name = 'registration/profile.html'
    
# @method_decorator(staff_member_required,name='dispatch')
# class Myprofile(TemplateView):
#     template_name = 'registration/profile.html'
    
    
def home(req):
    return render(req,"registration/home.html") 


# @login_required
# def profile(req):

#     return render(req,"registration/profile.html")


# @staff_member_required
# def profile(req):
#     return render(req,"registration/profile.html")
 

class Mychangepass(PasswordChangeView):
    template_name='registration/changepass.html'
    success_url='/changepassdone/'